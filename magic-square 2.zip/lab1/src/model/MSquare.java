package model;

/**
 * This class is in charge to the magic square and the method to generate it
 * @author Santiago Valencia Ramirez
 */

public class MSquare{
	
	/**
	 * This method generates the magic square
	 * @param n
	 * @param start
	 * @param direction
	 * @return magicSquare
	 */
	
	//Function to generate odd sized magic squares
	public int[][] generateSquare(int n, String start, String direction) {
		
		int[][] magicSquare = new int[n][n];
		
		int i = n;
		int j = n;
		
		if(start.equals("UP")) {
			
			//initialize position for 1
			i = 0;
			j = n/2;
			
			if(direction.equals("NO")) {
				//one by one put all the values
				for(int num = 1; num <= n*n;) {
					//3rd condition
					if(i == -1 && j == -1) {
						j = 0;
						i = 1;
					}else {
						//if next number goes to out of the magic square's
						//left side
						if(j == -1) {
							j = n-1;
						}
						//if next number goes to out of the magic square's
						//upper side
						if(i == -1) {
							i = n-1;
						}
					}
					//2nd condition
					if(magicSquare[i][j] != 0) {
						j++;
						i += 2;
						continue;
					}else {
						//set number
						magicSquare[i][j] = num++;
						//1st condition 
						j--; 
						i--;
					}
				}
			}else if(direction.equals("NE")) {
				//one by one put all the values
				for(int num = 1; num <= n*n;) {
					//3rd condition
					if(i == -1 && j == n) {
						j = n-1;
						i = 1;
					}else {
						//if next number goes to out of the magic square's
						//right side
						if(j == n) {
							j = 0;
						}
						//if next number goes to out of the magic square's
						//upper side
						if(i == -1) {
							i = n-1;
						}
					}
					//2nd condition
					if(magicSquare[i][j] != 0) {
						j--;
						i += 2;
						continue;
					}else {
						//set number
						magicSquare[i][j] = num++;
						//1st condition 
						j++; 
						i--;
					}
				}
			}
			
		}else if(start.equals("RIGHT")) {
			
			//initialize position for 1
			i = n/2;
			j = n-1;
			
			if(direction.equals("NE")) {
				//one by one put all the values
				for(int num = 1; num <= n*n;) {
					//3rd condition
					if(i == -1 && j == n) {
						j = n-2;
						i = 0;
					}else {
						//if next number goes to out of the magic square's
						//right side
						if(j == n) {
							j = 0;
						}
						//if next number goes to out of the magic square's
						//upper side
						if(i < 0) {
							i = n-1;
						}
					}
					//2nd condition
					if(magicSquare[i][j] != 0) {
						j -= 2;
						i++;
						continue;
					}else {
						//set number
						magicSquare[i][j] = num++;
						//1st condition 
						j++; 
						i--;
					}
				}
			}else if(direction.equals("SE")) {
				//one by one put all the values
				for(int num = 1; num <= n*n;) {
					//3rd condition diagonal
					if(i > n-1 && j > n-1) {
						j = n-2;
						i = n-1;
					}else {
						//if next number goes to out of the magic square's
						//right side
						if(j == n) {
							j = 0;
						}
						//if next number goes to out of the magic square's
						//down side
						if(i == n) {
							i = 0;
						}
					}
					//2nd condition
					if(magicSquare[i][j] != 0) {
						j -= 2;
						i--;
						continue;
					}else {
						//set number
						magicSquare[i][j] = num++;
						//1st condition 
						j++; 
						i++;
					}
				}
			}
		}else if(start.equals("LEFT")) {
			
			//initialize position for 1
			 i = n/2;
			 j = 0;
			 
			 if(direction.equals("SO")) {
				//one by one put all the values
					for(int num = 1; num <= n*n;) {
						//3rd condition
						if(i > n-1 && j == -1) {
							j = 1;
							i = n-1;
						}else {
							//if next number goes to out of the magic square's
							//left side
							if(j == -1) {
								j = n-1;
							}
							//if next number goes to out of the magic square's
							//down side
							if(i == n) {
								i = 0;
							}
						}
						//2nd condition
						if(magicSquare[i][j] != 0) {
							j += 2;
							i--;
							continue;
						}else {
							//set number
							magicSquare[i][j] = num++;
							//1st condition 
							j--; 
							i++;
						}
					}
				}else if(direction.equals("NO")) {
					//one by one put all the values
					for(int num = 1; num <= n*n;) {
						//3rd condition
						if(i == -1 && j == -1) {
							j = 1;
							i = 0;
						}else {
							//if next number goes to out of the magic square's
							//left side
							if(j == -1) {
								j = n-1;
							}
							//if next number goes to out of the magic square's
							//upper side
							if(i == -1) {
								i = n-1;
							}
						}
						//2nd condition
						if(magicSquare[i][j] != 0) {
							j += 2;
							i++;
							continue;
						}else {
							//set number
							magicSquare[i][j] = num++;
							//1st condition 
							j--; 
							i--;
						}
					}
				}
			 }else if(start.equals("DOWN")) {
					
				 //initialize position for 1
				 i = n-1;
				 j = n/2;
				 
				 if(direction.equals("SE")) {
					//one by one put all the values
						for(int num = 1; num <= n*n;) {
							//3rd condition diagonal
							if(i > n-1 && j > n-1) {
								j = n-1;
								i = n-2;
							}else {
								//if next number goes to out of the magic square's
								//right side
								if(j == n) {
									j = 0;
								}
								//if next number goes to out of the magic square's
								//down side
								if(i == n) {
									i = 0;
								}
							}
							//2nd condition
							if(magicSquare[i][j] != 0) {
								j--;
								i -= 2;
								continue;
							}else {
								//set number
								magicSquare[i][j] = num++;
								//1st condition 
								j++; 
								i++;
							}
						}
				 }else if(direction.equals("SO")) {
					//one by one put all the values
						for(int num = 1; num <= n*n;) {
							//3rd condition
							if(i > n-1 && j == -1) {
								j = 0;
								i = n-2;
							}else {
								//if next number goes to out of the magic square's
								//left side
								if(j == -1) {
									j = n-1;
								}
								//if next number goes to out of the magic square's
								//down side
								if(i == n) {
									i = 0;
								}
							}
							//2nd condition
							if(magicSquare[i][j] != 0) {
								j++;
								i -= 2;
								continue;
							}else {
								//set number
								magicSquare[i][j] = num++;
								//1st condition 
								j--; 
								i++;
							}
						}
				 }
				 
			}
			
		return magicSquare;
	}
}