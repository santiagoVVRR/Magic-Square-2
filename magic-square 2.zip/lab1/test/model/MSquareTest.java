package model;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * This class is in charge to make some tests to the program
 * @author Santiago Valencia Ramirez
 */

public class MSquareTest {

	private MSquare square;
	
	void setupScenary1() {
		square = new MSquare();
		
	}
	
	@Test
	void testNotNull() {
		setupScenary1();
		
		square.generateSquare(3, "UP", "NO");
		assertNotNull(square, "The matriz is not null");
		
	}
	
	@Test
	void testUpNo() {
		setupScenary1();
		
		int [][] g = square.generateSquare(3, "UP", "NO");
		int [][] m = {{6,1,8},{7,5,3},{2,9,4}};
		for(int i = 0; i < m.length; i++) {
			for(int j = 0; j < m[i].length; j++) {
				assertTrue("Is correct", g[i][j] == m[i][j]);
			}
		}
	}

	@Test
	void testUpNe() {
		setupScenary1();
		
		int [][] g = square.generateSquare(3, "UP", "NE");
		int [][] m = {{8,1,6},{3,5,7},{4,9,2}};
		for(int i = 0; i < m.length; i++) {
			for(int j = 0; j < m[i].length; j++) {
				assertTrue("Is correct", g[i][j] == m[i][j]);
			}
		}
	}

	@Test
	void testDownSo() {
		setupScenary1();
		
		int [][] g = square.generateSquare(3, "DOWN", "SO");
		int [][] m = {{2,9,4},{7,5,3},{6,1,8}};
		for(int i = 0; i < m.length; i++) {
			for(int j = 0; j < m[i].length; j++) {
				assertTrue("Is correct", g[i][j] == m[i][j]);
			}
		}
	}

	@Test
	void testDownSe() {
		setupScenary1();
		
		int [][] g = square.generateSquare(3, "DOWN", "SE");
		int [][] m = {{4,9,2},{3,5,7},{8,1,6}};
		for(int i = 0; i < m.length; i++) {
			for(int j = 0; j < m[i].length; j++) {
				assertTrue("Is correct", g[i][j] == m[i][j]);
			}
		}
	}
	
}
