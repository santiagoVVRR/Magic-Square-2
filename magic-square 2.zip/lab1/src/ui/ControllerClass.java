package ui;



import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.RowConstraints;
import model.MSquare;

/**
 * This class is in charge to control the action in the user interface
 * @author Santiago Valencia Ramirez
 */

public class ControllerClass {
	
	private MSquare matriz;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField size;

    @FXML
    private ComboBox<String> start;

    @FXML
    private ComboBox<String> direction;

    @FXML
    private Button btn;

    @FXML
    private GridPane gridd;

    /**
     * This method is in charge to control the button actions
     * @param event
     */
    @FXML
    void generateMS(ActionEvent event) {
    	
    	try {
    		gridd.getChildren().clear();

        	
        	gridd.setAlignment(Pos.BOTTOM_CENTER);
        	
        	boolean flag = true;
        	String startP = start.getValue();
        	MouseEvent m = null;
        	boolean inFlag = items(m, startP);
        	int num = Integer.parseInt(size.getText());
        	String directionP = direction.getValue();
        	
        	if(num%2 == 0) {
        		flag = false;
        		Alert a = new Alert(AlertType.INFORMATION, "WRONG", ButtonType.OK);
        		a.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        		a.show();
        		size.setText("");
        	}
        	if(flag == true && inFlag == true) {
        		int[][]ma=matriz.generateSquare(num,startP,directionP);
             	for (int rowIndex = 0; rowIndex < num; rowIndex++) { 
             	   for (int colIndex = 0; colIndex < num; colIndex++) {
             		   //533
             		   //263
             		 int n=ma[rowIndex][colIndex];
             		 Button lab = new Button(""+n); 
             		 lab.setStyle("-fx-border-color: Black; -fx-font-size: 10;-fx-background-color: LightGray;");
             		 lab.setPrefWidth(gridd.getWidth()/num);
             		lab.setPrefHeight(gridd.getHeight()/num);
             		 GridPane.setConstraints(lab, colIndex, rowIndex, 1, 1);
             		 gridd.getChildren().addAll(lab);
             		 gridd.setMaxSize(Region.BASELINE_OFFSET_SAME_AS_HEIGHT,Region.BASELINE_OFFSET_SAME_AS_HEIGHT);
             		 
        			}
        		}
        		direction.getItems().clear();
        		direction.setVisible(false);
        		btn.setText("continue");
        		btn.setStyle("-fx-background-color: Red");
        	}
    	}catch(NullPointerException l){
    		System.out.println("No afecta el desarrollo del programa");
    	}catch(NumberFormatException d) {
    		System.out.println("The value is not a number");
    	}catch(NegativeArraySizeException j) {
    		System.out.println("The matriz cannot be negative");
    	}
    	
    }
    /**
     * This method is i charge to set the visibility  of the ComboBox direction and enables
     * some items from it according to the mouse event in the start ComboBox
     * @param invent
     * @param op
     * @return c
     */
    public boolean items(MouseEvent invent, String op) {
		boolean c = false;
		direction.setVisible(true);
		
		 if(op.equals("UP")) {
	        	direction.getItems().add("NO");
	            direction.getItems().add("NE");    
	        }else if(op.equals("DOWN")) {
	        	direction.getItems().add("SO");
	            direction.getItems().add("SE");
	        }else if(op.equals("RIGHT")) {
	        	direction.getItems().add("NE");   
	            direction.getItems().add("SE");
	        }else if(op.equals("LEFT")) {	
	        	direction.getItems().add("NO");   
	        	direction.getItems().add("SO");
	        }
		 c = true;
		 btn.setText("Start");
	     btn.setStyle("-fx-background-color: LightGreen");
		
		return c;
	}

	/**
	 * This method is in charge to initialize the start ComboBox and the matriz
	 */
    public void initialize() {
        
		direction.setVisible(false);
		matriz = new MSquare();
		
    	start.getItems().add("UP");
    	start.getItems().add("RIGHT");
    	start.getItems().add("LEFT");
    	start.getItems().add("DOWN");
    	btn.setText("Continue");
    	

    }
	
	
}
